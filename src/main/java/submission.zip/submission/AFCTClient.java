package submission;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import gui.Globals;

import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustAllStrategy;
import org.apache.http.ssl.SSLContextBuilder;

import javax.net.ssl.*;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.http.*;
import java.nio.file.Files;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import static gui.Globals.stringToJson;

public final class AFCTClient {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    // Immutable configuration
    private final String baseUrl;
    private final boolean insecureTls;
    private final Duration connectTimeout;
    private final Duration readTimeout;
    private final int maxRetries;
    private final long baseBackoffMs;

    private final HttpClient httpClient;

    // Thread-safe token
    private final AtomicReference<String> token = new AtomicReference<>();

    // Refresh handling
    private final Object refreshLock = new Object();
    private volatile String lastEmail;
    private volatile String lastPassword;

    // ============================================================
    // BUILDER ENTRY
    // ============================================================

    public static Builder builder(String baseUrl) {
        return new Builder(baseUrl);
    }

    public static final class Builder {

        private final String baseUrl;

        private boolean insecureTls = true; // default as requested
        private Duration connectTimeout = Duration.ofSeconds(15);
        private Duration readTimeout = Duration.ofSeconds(30);
        private int maxRetries = 3;
        private long baseBackoffMs = 300;

        private Builder(String baseUrl) {
            this.baseUrl = fixUrl(baseUrl);
        }

        public Builder insecureTls(boolean insecureTls) {
            this.insecureTls = insecureTls;
            return this;
        }

        public Builder connectTimeoutSeconds(int seconds) {
            this.connectTimeout = Duration.ofSeconds(seconds);
            return this;
        }

        public Builder readTimeoutSeconds(int seconds) {
            this.readTimeout = Duration.ofSeconds(seconds);
            return this;
        }

        public Builder maxRetries(int retries) {
            this.maxRetries = retries;
            return this;
        }

        public Builder baseBackoffMs(long ms) {
            this.baseBackoffMs = ms;
            return this;
        }

        public AFCTClient build() {
            return new AFCTClient(
                    baseUrl,
                    insecureTls,
                    connectTimeout,
                    readTimeout,
                    maxRetries,
                    baseBackoffMs
            );
        }
    }

    // ============================================================
    // PRIVATE CONSTRUCTOR
    // ============================================================

    private AFCTClient(String baseUrl,
                       boolean insecureTls,
                       Duration connectTimeout,
                       Duration readTimeout,
                       int maxRetries,
                       long baseBackoffMs) {

        this.baseUrl = baseUrl;
        this.insecureTls = insecureTls;
        this.connectTimeout = connectTimeout;
        this.readTimeout = readTimeout;
        this.maxRetries = maxRetries;
        this.baseBackoffMs = baseBackoffMs;

        this.httpClient = buildClient();
    }

    // ============================================================
    // AUTH
    // ============================================================

    public String login(String email, String password) throws IOException {
        this.lastEmail = email;
        this.lastPassword = password;
        return performLogin(email, password);
    }

    private String performLogin(String email, String password) throws IOException {
        try {
            String json = MAPPER.writeValueAsString(
                    Map.of("email", email, "password", password)
            );

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(baseUrl + "/api/public/login"))
                    .timeout(readTimeout)
                    .POST(HttpRequest.BodyPublishers.ofString(json))
                    .header("Content-Type", "application/json")
                    .build();

            HttpResponse<String> response = sendWithRetry(request);

            if (response.statusCode() != 200) {
                throw httpError("POST /api/public/login",
                        response.statusCode(),
                        response.body());
            }

            Map<String, Object> res = MAPPER.readValue(response.body(), Map.class);
            String jwt = (String) res.get("token");
            token.set(jwt);
            return jwt;

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Login interrupted", e);
        }
    }

    private void refreshToken() throws IOException {
        if (lastEmail == null || lastPassword == null) {
            throw new IOException("No stored credentials for refresh.");
        }

        synchronized (refreshLock) {
            performLogin(lastEmail, lastPassword);
        }
    }

    public boolean isAuthenticated() {
        String t = token.get();
        return t != null && !t.isBlank();
    }

    private void ensureAuth() throws IOException {
        if (!isAuthenticated()) {
            throw new IOException("Not authenticated; call login() first.");
        }
    }

    // ============================================================
    // API CALLS
    // ============================================================

    @SuppressWarnings("unchecked")
    public List<Map<String, Object>> getCourses(String userEmail) throws IOException {
        ensureAuth();
        return sendJsonList("/api/courses/userCourses/" + userEmail);
    }

    @SuppressWarnings("unchecked")
    public List<Map<String, Object>> getAssignments(String courseId) throws IOException {
        ensureAuth();
        return sendJsonList("/api/courses/" + courseId + "/assignments");
    }

    @SuppressWarnings("unchecked")
    public List<Map<String, Object>> getProblems(String assignmentId) throws IOException {
        ensureAuth();
        return sendJsonList("/api/assignments/" + assignmentId + "/problems");
    }

    // ============================================================
    // CORE SEND + RETRY + REFRESH
    // ============================================================

    private HttpResponse<String> sendWithRetry(HttpRequest request)
            throws IOException, InterruptedException {

        int attempt = 0;

        while (true) {
            try {
                HttpResponse<String> response =
                        httpClient.send(request, HttpResponse.BodyHandlers.ofString());

                if (response.statusCode() == 401 && attempt == 0) {
                    refreshToken();
                    request = rebuildWithNewToken(request);
                    attempt++;
                    continue;
                }

                if (response.statusCode() >= 500 && attempt < maxRetries) {
                    backoff(attempt);
                    attempt++;
                    continue;
                }

                return response;

            } catch (IOException e) {
                if (attempt >= maxRetries) throw e;
                backoff(attempt);
                attempt++;
            }
        }
    }

    private void backoff(int attempt) {
        long delay = (long) (baseBackoffMs * Math.pow(2, attempt));
        long jitter = (long) (Math.random() * 100);
        try {
            Thread.sleep(delay + jitter);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }

    private HttpRequest rebuildWithNewToken(HttpRequest original) {
        HttpRequest.Builder builder = HttpRequest.newBuilder()
                .uri(original.uri())
                .timeout(original.timeout().orElse(readTimeout))
                .method(original.method(),
                        original.bodyPublisher().orElse(HttpRequest.BodyPublishers.noBody()));

        original.headers().map().forEach((k, v) -> {
            if (!k.equalsIgnoreCase("Authorization")) {
                v.forEach(val -> builder.header(k, val));
            }
        });

        String jwt = token.get();
        if (jwt != null) {
            builder.header("Authorization", "Bearer " + jwt);
        }

        return builder.build();
    }

    private List<Map<String, Object>> sendJsonList(String path)
            throws IOException {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(baseUrl + path))
                    .timeout(readTimeout)
                    .header("Authorization", "Bearer " + token.get())
                    .GET()
                    .build();

            HttpResponse<String> response = sendWithRetry(request);

            if (response.statusCode() != 200) {
                throw httpError("GET " + path,
                        response.statusCode(),
                        response.body());
            }

            return MAPPER.readValue(response.body(), List.class);

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Request interrupted", e);
        }
    }

    // ============================================================
    // TLS
    // ============================================================

    private HttpClient buildClient() {
        System.out.println("=== AFCTClient.buildClient() ===");
        System.out.println("insecureTls: " + insecureTls);

        if (insecureTls) {
            System.out.println("Applying INSECURE TLS settings...");
            try {
                SSLContext sslContext = SSLContextBuilder.create()
                        .loadTrustMaterial(new TrustAllStrategy())
                        .build();

                // Disable hostname verification (SAN / CN checks)
                SSLParameters sslParams = new SSLParameters();
                sslParams.setEndpointIdentificationAlgorithm(null);

                HttpClient client = HttpClient.newBuilder()
                        .connectTimeout(connectTimeout)
                        .version(HttpClient.Version.HTTP_1_1)
                        .sslContext(sslContext)
                        .sslParameters(sslParams) // ✅ THIS WAS MISSING
                        .build();

                System.out.println("✓ Trust-all SSL context created");
                System.out.println("✓ Hostname verification disabled");
                System.out.println("================================");

                return client;

            } catch (Exception e) {
                System.err.println("❌ Failed to configure insecure TLS: " + e.getMessage());
                e.printStackTrace();
                throw new RuntimeException("Failed to configure TLS", e);
            }
        }

        System.out.println("Using SECURE TLS (default Java settings)");
        System.out.println("================================");

        return HttpClient.newBuilder()
                .connectTimeout(connectTimeout)
                .version(HttpClient.Version.HTTP_2)
                .build();
    }


    private static SSLContext insecureContext() throws GeneralSecurityException {
        TrustManager[] trustAll = new TrustManager[]{
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
                    public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                    public void checkServerTrusted(X509Certificate[] certs, String authType) {}
                }
        };

        SSLContext sc = SSLContext.getInstance("TLS");
        sc.init(null, trustAll, new SecureRandom());
        return sc;
    }

    private static SSLParameters disableHostnameVerification() {
        SSLParameters params = new SSLParameters();
        params.setEndpointIdentificationAlgorithm(null);
        return params;
    }

    // ============================================================
    // UTILITIES
    // ============================================================

    private static IOException httpError(String label, int status, String body) {
        try {
            JsonObject jsonBody = stringToJson(body);
            if (jsonBody.has("error")) {
                return new IOException(jsonBody.get("error").getAsString());
            }
        } catch (JsonSyntaxException ignored) {}

        return new IOException("HTTP " + status + " on " + label);
    }

    public static String fixUrl(String baseUrl) {
        String fixed = baseUrl.trim();
        if (fixed.endsWith("/")) {
            fixed = fixed.substring(0, fixed.length() - 1);
        }
        if (!fixed.startsWith("http://") && !fixed.startsWith("https://")) {
            fixed = "http://" + fixed;
        }
        return fixed;
    }
}
