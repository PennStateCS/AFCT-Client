package submission;

public final class CourseItem {

    public final String id;
    public final String title;

    public CourseItem(String id, String title) {
        this.id = id;
        this.title = title;
    }

    @Override
    public String toString() {
        return title;
    }
}
