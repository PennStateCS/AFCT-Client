package submission;

import gui.Globals;

import javax.swing.*;
import java.awt.*;

import static gui.Globals.*;
import static submission.AFCTClient.fixUrl;

public class LoginWindow extends JDialog {

    private final SessionHandler sessionHandler;

    private final JTextField serverTF = new JTextField("https://10.144.18.20");
    private final JTextField portTF = new JTextField("443");
    private final JTextField emailTF = new JTextField();
    private final JPasswordField passwordTF = new JPasswordField();

    private final JCheckBox validateSSLCheckBox =
            new JCheckBox("Validate SSL Certificate");

    private final JCheckBox showPasswordCheckBox =
            new JCheckBox("Show password");

    private final JButton loginButton = new JButton("Login");
    private final JLabel resultLabel = new JLabel(" ");

    public LoginWindow(SessionHandler handler) {
        super((Frame) null, "Login - " + Globals.APP_NAME, true);
        this.sessionHandler = handler;

        buildUI();
        populateFromSessionState();

        pack();
        setResizable(false);
        setLocationRelativeTo(Globals.getActiveWindow());

        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    }

    // ============================================================
    // DISPLAY
    // ============================================================

    public void displayLoginWindow() {
        resultLabel.setText(" ");
        passwordTF.setText("");
        populateFromSessionState();
        toggleInputs(true);
        setVisible(true); // modal => blocks until disposed/hidden
    }

    // ============================================================
    // UI
    // ============================================================

    private void buildUI() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(18, 22, 18, 22));

        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        c.insets = new Insets(6, 0, 6, 0);

        JLabel header = new JLabel("AFCT Server Login");
        boldFontAndChangeSize(header, 20);
        header.setHorizontalAlignment(SwingConstants.CENTER);

        c.insets = new Insets(0, 0, 14, 0);
        panel.add(header, c);

        c.gridy++;
        c.insets = new Insets(6, 0, 6, 0);
        panel.add(labeled("Server", serverTF), c);

        c.gridy++;
        panel.add(labeled("Port", portTF), c);

        c.gridy++;
        panel.add(labeled("Email", emailTF), c);

        c.gridy++;
        panel.add(labeled("Password", passwordTF), c);

        // small options row (show password + SSL validation)
        c.gridy++;
        c.insets = new Insets(10, 0, 4, 0);
        panel.add(buildOptionsRow(), c);

        // Login button
        c.gridy++;
        c.insets = new Insets(12, 0, 8, 0);
        loginButton.setPreferredSize(new Dimension(320, 38));
        loginButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        panel.add(loginButton, c);

        // Result label
        c.gridy++;
        c.insets = new Insets(2, 0, 0, 0);
        resultLabel.setHorizontalAlignment(SwingConstants.CENTER);
        changeSize(resultLabel, 14);
        panel.add(resultLabel, c);

        // events
        loginButton.addActionListener(e -> attemptLogin());
        getRootPane().setDefaultButton(loginButton);

        showPasswordCheckBox.setFocusPainted(false);
        showPasswordCheckBox.addActionListener(e -> {
            if (showPasswordCheckBox.isSelected()) {
                passwordTF.setEchoChar((char) 0);
            } else {
                // restore default echo char (bullet)
                passwordTF.setEchoChar('•');
            }
        });

        validateSSLCheckBox.setFocusPainted(false);

        setContentPane(panel);
    }

    private JPanel buildOptionsRow() {
        JPanel row = new JPanel(new GridBagLayout());
        row.setOpaque(false);

        GridBagConstraints c = new GridBagConstraints();
        c.gridy = 0;
        c.insets = new Insets(0, 0, 0, 12);
        c.anchor = GridBagConstraints.LINE_START;

        c.gridx = 0;
        row.add(showPasswordCheckBox, c);

        c.gridx = 1;
        c.insets = new Insets(0, 0, 0, 0);
        row.add(validateSSLCheckBox, c);

        return row;
    }

    private JPanel labeled(String label, JComponent comp) {
        JPanel p = new JPanel(new BorderLayout(0, 4));

        JLabel l = new JLabel(label);
        boldFont(l);

        if (comp instanceof JTextField tf) {
            tf.setMargin(new Insets(6, 10, 6, 10));
        } else if (comp instanceof JPasswordField pf) {
            pf.setMargin(new Insets(6, 10, 6, 10));
        }

        p.add(l, BorderLayout.NORTH);
        p.add(comp, BorderLayout.CENTER);
        return p;
    }

    private void toggleInputs(boolean enabled) {
        serverTF.setEnabled(enabled);
        portTF.setEnabled(enabled);
        emailTF.setEnabled(enabled);
        passwordTF.setEnabled(enabled);
        validateSSLCheckBox.setEnabled(enabled);
        showPasswordCheckBox.setEnabled(enabled);
        loginButton.setEnabled(enabled);
    }

    // ============================================================
    // LOGIN
    // ============================================================

    private void attemptLogin() {
        final String server = fixUrl(serverTF.getText().trim());
        final String port = portTF.getText().trim();
        final String email = emailTF.getText().trim();
        final String password = new String(passwordTF.getPassword());

        // checkbox means "validate cert" => insecureTls = false
        final boolean insecureTls = !validateSSLCheckBox.isSelected();

        // Show which mode we're using
        String sslMode = insecureTls ? "(SSL validation OFF)" : "(SSL validation ON)";
        resultLabel.setText("<html>Authenticating... " + sslMode + "</html>");
        toggleInputs(false);

        new SwingWorker<LoginResult, Void>() {
            @Override
            protected LoginResult doInBackground() {
                return sessionHandler.login(server, port, email, password, insecureTls);
            }

            @Override
            protected void done() {
                try {
                    LoginResult result = get();
                    if (result.status == LoginResult.LoginStatus.SUCCESS) {
                        resultLabel.setText("<html>" + colorHTMLSuccessMessage(result.message) + "</html>");
                        dispose();
                    } else {
                        resultLabel.setText("<html>" + colorHTMLErrorMessage(result.message) + "</html>");
                    }
                } catch (Exception ex) {
                    resultLabel.setText("<html>" + colorHTMLErrorMessage("Login Failure") + "</html>");
                } finally {
                    toggleInputs(true);
                }
            }
        }.execute();
    }

    // ============================================================
    // State load
    // ============================================================

    private void populateFromSessionState() {
        // These could be pulled from preferences later if you add getters.
        // For now keep defaults / user edits in the fields.
        validateSSLCheckBox.setSelected(!sessionHandler.isInsecureTls());
    }
}
