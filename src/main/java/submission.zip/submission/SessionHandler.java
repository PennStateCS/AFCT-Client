package submission;

import javax.swing.*;
import java.lang.reflect.InvocationTargetException;
import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.prefs.Preferences;

public class SessionHandler {

    // ===============================
    // Preferences
    // ===============================
    public static final String PREF_INSECURE_TLS = "insecure_tls";
    public static final String PREF_USE_APACHE_CLIENT = "use_apache_client";

    // Make this accessible to LoginWindow (your UI code expects it)
    public final Preferences preferences = Preferences.userNodeForPackage(SessionHandler.class);

    // ===============================
    // Thread safety
    // ===============================
    private final Object sessionLock = new Object();
    private final AtomicBoolean loggingOut = new AtomicBoolean(false);

    // ===============================
    // Session state
    // ===============================
    private AFCTClient client;
    private boolean loggedIn = false;

    private final LoginWindow loginWindow;

    // ===============================
    // Idle tracking
    // ===============================
    private volatile Instant lastActivityTime = Instant.now();
    private volatile Duration idleTimeout = Duration.ofMinutes(15);

    public SessionHandler() {
        this.loginWindow = new LoginWindow(this);
    }

    // ===============================
    // TLS preference
    // ===============================
    public void setInsecureTls(boolean insecure) {
        preferences.putBoolean(PREF_INSECURE_TLS, insecure);
    }

    /** default = false => validate SSL by default */
    public boolean isInsecureTls() {
        return preferences.getBoolean(PREF_INSECURE_TLS, false);
    }

    // ===============================
    // Authentication Gate
    // ===============================
    public AFCTClient requireAuthenticated() {

        synchronized (sessionLock) {
            checkIdleTimeoutLocked();
            if (client != null && client.isAuthenticated()) {
                markActivityLocked();
                return client;
            }
        }

        showLoginDialogBlocking();

        synchronized (sessionLock) {
            if (client != null && client.isAuthenticated()) {
                markActivityLocked();
                return client;
            }
            return null;
        }
    }

    private void showLoginDialogBlocking() {
        if (SwingUtilities.isEventDispatchThread()) {
            loginWindow.displayLoginWindow(); // modal
            return;
        }

        try {
            SwingUtilities.invokeAndWait(loginWindow::displayLoginWindow);
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        } catch (InvocationTargetException ite) {
            ite.getCause().printStackTrace();
        }
    }

    // ===============================
    // Login
    // ===============================

    /** Backwards-compatible: uses stored TLS pref */
    public LoginResult login(String server, String port, String email, String password) {
        return login(server, port, email, password, isInsecureTls());
    }

    /** Preferred: explicit TLS choice for *this* attempt */
    public LoginResult login(String server,
                             String port,
                             String email,
                             String password,
                             boolean insecureTls) {

        synchronized (sessionLock) {
            try {
                // Debug output
                System.out.println("=== LOGIN DEBUG ===");
                System.out.println("Server: " + server + ":" + port);
                System.out.println("insecureTls: " + insecureTls);
                System.out.println("==================");

                // Persist TLS choice so next time UI opens it matches
                setInsecureTls(insecureTls);

                client = AFCTClient.builder(server + ":" + port)
                        .insecureTls(insecureTls)
                        .build();

                String jwt = client.login(email, password);

                if (jwt != null && !jwt.isBlank()) {
                    loggedIn = true;
                    markActivityLocked();
                    return LoginResult.getSuccessResult();
                }

                loggedIn = false;
                client = null;
                return LoginResult.getFailureResult();

            } catch (Exception e) {
                loggedIn = false;
                client = null;
                return LoginResult.getErrorResult(e.getMessage());
            }
        }
    }

    // ===============================
    // Logout
    // ===============================
    public void logout() {
        logout(true);
    }

    public void logout(boolean showLoginDialogAfter) {

        if (loggingOut.getAndSet(true)) return;

        try {
            synchronized (sessionLock) {
                loggedIn = false;
                client = null;
                lastActivityTime = Instant.now();
            }

            if (showLoginDialogAfter) {
                SwingUtilities.invokeLater(loginWindow::displayLoginWindow);
            }
        } finally {
            loggingOut.set(false);
        }
    }

    // ===============================
    // Idle Tracking
    // ===============================
    public void setIdleTimeoutMinutes(long minutes) {
        if (minutes <= 0) minutes = 1;
        idleTimeout = Duration.ofMinutes(minutes);
    }

    public boolean isAuthenticated() {
        synchronized (sessionLock) {
            return client != null && client.isAuthenticated();
        }
    }

    private void markActivityLocked() {
        lastActivityTime = Instant.now();
    }

    private void checkIdleTimeoutLocked() {
        if (!loggedIn) return;

        Duration idle = Duration.between(lastActivityTime, Instant.now());
        if (idle.compareTo(idleTimeout) > 0) {
            loggedIn = false;
            client = null;
            lastActivityTime = Instant.now();
        }
    }
}
