package submission;

public final class AssignmentItem {

    public final String id;
    public final String title;
    public final String description;

    public AssignmentItem(String id, String title, String description) {
        this.id = id;
        this.title = title;
        this.description = description;
    }

    @Override
    public String toString() {
        return title;
    }
}
