package submission;

import gui.environment.Environment;
import gui.environment.Universe;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class SubmitWindow extends JFrame implements SubmissionGUI{

    private final Environment environment;

    public SubmitWindow(Environment environment) {
        super("Submit");

        this.environment = environment;

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        buildUI();

        // 🔥 Proper cleanup on close
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                Universe.unregisterSubmitDialog(environment);
            }
        });
    }

    // ===============================
    // UI
    // ===============================

    private void buildUI() {

        JPanel panel = new JPanel(new BorderLayout());

        JLabel label = new JLabel(
                "Submission Window",
                SwingConstants.CENTER
        );

        label.setFont(label.getFont().deriveFont(Font.BOLD, 16f));

        panel.add(label, BorderLayout.CENTER);

        JButton closeButton = new JButton("Close");

        closeButton.addActionListener(e -> dispose());

        panel.add(closeButton, BorderLayout.SOUTH);

        setContentPane(panel);
    }

    // ===============================
    // Display
    // ===============================

    public void displaySubmitWindow() {
        setVisible(true);
        toFront();
    }

    @Override
    public void refreshDialog()
    {

    }
}
